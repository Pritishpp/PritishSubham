package co.xeeroo.pwmtool.repository;

import co.xeeroo.pwmtool.domain.Backlog;
import co.xeeroo.pwmtool.domain.Project;
import co.xeeroo.pwmtool.domain.ProjectTask;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProjectTaskRepository extends CrudRepository<ProjectTask,Long> {
    List<ProjectTask> findByProjectIdentifierOrderByPriority(String id);
    ProjectTask findByProjectSequence(String pt_id);


}
