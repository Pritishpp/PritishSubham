package co.xeeroo.pwmtool.repository;

import co.xeeroo.pwmtool.domain.Project;
import org.springframework.data.repository.CrudRepository;

public interface SubhamRepository extends CrudRepository<Project,Long> {

    @Override
    Iterable<Project> findAll();

}
