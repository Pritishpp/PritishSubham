package co.xeeroo.pwmtool.web;

import co.xeeroo.pwmtool.domain.Project;
import co.xeeroo.pwmtool.services.ProjectService;
import co.xeeroo.pwmtool.services.SubhamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/subham")
public class SubhamController {
    @Autowired
    private SubhamService subhamService;
    @GetMapping("/all")
    public Iterable<Project> getAllProject(){
        return subhamService.findAllProject();
    }
}
