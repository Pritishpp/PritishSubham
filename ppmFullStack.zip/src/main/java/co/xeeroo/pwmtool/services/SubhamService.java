package co.xeeroo.pwmtool.services;

import co.xeeroo.pwmtool.domain.Project;
import co.xeeroo.pwmtool.repository.ProjectRepository;
import co.xeeroo.pwmtool.repository.SubhamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubhamService {
    @Autowired
    SubhamRepository subhamRepository;
    public  Iterable<Project> findAllProject(){
        return  subhamRepository.findAll();
    }
}
