package co.xeeroo.pwmtool.services;

import co.xeeroo.pwmtool.domain.Backlog;
import co.xeeroo.pwmtool.domain.Project;
import co.xeeroo.pwmtool.exceptions.ProjectIdException;
import co.xeeroo.pwmtool.repository.BacklogRepository;
import co.xeeroo.pwmtool.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProjectService {
    /**
     *
     */
    @Autowired
    private ProjectRepository projectRepository;
    @Autowired
    private BacklogRepository backlogRepository;

    public Project saveOrUpdateProject(Project project){
       try {
           project.setProjectIdentifier(project.getProjectIdentifier().toUpperCase());
           if(project.getId()==null){
               Backlog backlog = new Backlog();
               project.setBacklog(backlog);
               backlog.setProject(project);
               backlog.setProjectIdentifier(project.getProjectIdentifier().toUpperCase());
           }
           if(project.getId()!=null){
               project.setBacklog(backlogRepository.findByProjectIdentifier(project.getProjectIdentifier().toUpperCase()));
           }
       return projectRepository.save(project);
       }catch (Exception e){
           throw new ProjectIdException("Project Id '"+project.getProjectIdentifier().toUpperCase()+"' already exist");

        }
    }

    public Project findProjectByIdentifier(String projectId) {
        Project project = projectRepository.findByProjectIdentifier(projectId);
        if(project == null){
            throw new ProjectIdException("Project Id '"+projectId+"' does not exist");

        }
        return project;
    }
    public  Iterable<Project> findAllProject(){
        return  projectRepository.findAll();
    }
    public void deleteProjectByIdentifier(String projectid){
        Project project = projectRepository.findByProjectIdentifier(projectid.toUpperCase());
        if(project==null){
            throw new ProjectIdException("can not Project with Id"+projectid+"this project doesnot exist");
        }
        projectRepository.delete(project);
    }
}
